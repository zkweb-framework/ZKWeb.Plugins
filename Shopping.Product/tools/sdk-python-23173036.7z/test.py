# -*- coding: utf-8 -*-
import top.api
top.setDefaultAppInfo("1023173036", "sandbox14c8f46ef464a48929a2652c8")

def getArea():
	a = top.api.AreasGetRequest("gw.api.tbsandbox.com")
	a.fields="id,type,name,parent_id,zip"
	try:
		r = a.getResponse()
		open("area.json", "wb").write(repr(r))
	except Exception as e:
		print repr(e)

def getCategories():
	allCategories = []
	def addCategoriesUnder(id):
		print "addCategoriesUnder %s"%id
		a = top.api.ItemcatsGetRequest("gw.api.tbsandbox.com")
		a.fields = "cid,parent_cid,name,is_parent"
		a.parent_cid = id
		r = None
		try:
			r = a.getResponse()
			categories = r["itemcats_get_response"].get("item_cats", {}).get("item_cat", {})
			for category in categories:
				allCategories.append(category)
				addCategoriesUnder(int(category["cid"]))
		except Exception as e:
			print repr(e)
	addCategoriesUnder(0)
	open("categories.json", "wb").write(repr(allCategories))

def getProperties():
	import collections
	allProperties = collections.defaultdict(list) # {pid: [property, ...]}
	propertyReleations = collections.defaultdict(list) # {cid: [pid, ...], ...}
	def addPropertiesUnder(id):
		print "addPropertiesUnder %s"%id
		a = top.api.ItempropsGetRequest("gw.api.tbsandbox.com")
		a.fields = ("pid,name,must,multi,prop_values,is_key_prop," + 
			"is_sale_prop,is_color_prop,is_enum_prop,is_item_prop,is_allow_alias," +
			"is_input_prop,type,status")
		a.cid = id
		try:
			r = a.getResponse()
			properties = r["itemprops_get_response"].get("item_props", {}).get("item_prop", {})
			for p in properties:
				pid = int(p["pid"])
				existProperties = allProperties[pid]
				for ep in existProperties:
					if (p["name"] == ep["name"] and
						repr(p.get("prop_values")) == repr(ep.get("prop_values"))):
						# print "merged property %s"%p["name"]
						ep["cids"].append(id)
						break
				else:
					if existProperties:
						print "add derived property %s"%p["name"]
					p["cids"] = [id]
					existProperties.append(p)
				propertyReleations[id].append(pid)
			propertyReleations[id] = map(lambda p: int(p["pid"]), properties)
		except Exception as e:
			print repr(e)
	import ast
	categories = ast.literal_eval(open("categories.json", "rb").read())
	for category in categories:
		addPropertiesUnder(int(category["cid"]))
	open("properties.json", "wb").write(repr(dict(allProperties)))
	open("propertie_releations.json", "wb").write(repr(dict(propertyReleations)))

getProperties()


