# -*- coding: utf-8 -*-
import ast

with open("area.json") as r:
	obj = ast.literal_eval(r.read())
	areas = obj["areas_get_response"]["areas"]["area"]

	areas_formated = []
	id_added = set()
	for area in areas:
		id = area["id"]
		parent_id = area["parent_id"]
		name = area["name"].encode("utf-8")
		if parent_id == 0 or id < 10000:
			continue # skip country outside of china
		if id in id_added:
			print "duplicated area %s"%name
			continue
		id_added.add(id)
		if parent_id == 1:
			parent_id = 0 # first level area under china
		areas_formated.append((id, parent_id, name))
	areas_formated.sort(key = lambda a: a[0])

	with open("area.txt", "wb") as w:
		w.write("[\r\n")
		for index, area in enumerate(areas_formated):
			w.write("{ Id: %s, ParentId: %s, Name: \"%s\" }"%area)
			if index < len(areas_formated) - 1:
				w.write(",")
			w.write("\r\n")
		w.write("]\r\n")
