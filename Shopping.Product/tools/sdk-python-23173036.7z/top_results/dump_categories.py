# -*- coding: utf-8 -*-
import ast

with open("categories.json") as r:
	categories = ast.literal_eval(r.read())

with open("properties.json") as r:
	properties = ast.literal_eval(r.read())

with open("propertie_releations.json") as r:
	propertieReleations = ast.literal_eval(r.read())

# id, parent_id, name, property_ids
categories_formated = []
for category in categories:
	id = category["cid"]
	parent_id = category["parent_cid"]
	name = category["name"].encode("utf-8")
	if "\"" in name or name.endswith("\\"):
		print "category name %s invalid"%category["name"]
		continue
	property_ids = ", ".join(map(str, propertieReleations[id]))
	property_ids = "[ %s ]"%property_ids if property_ids else "[]"
	categories_formated.append((id, parent_id, name, property_ids))
categories_formated.sort(key = lambda c: c[0])
with open("categories.txt", "wb") as w:
	w.write("[\r\n")
	for index, category in enumerate(categories_formated):
		w.write("{ Id: %s, ParentId: %s, Name: \"%s\", PropertyIds: %s}"%category)
		if index < len(categories_formated) - 1:
			w.write(",")
		w.write("\r\n")
	w.write("]\r\n")

# id, parent_ids, name, is_sale_property, control_type, property_value_ids
class InputControlType:
	Textbox = 0
	CheckBox = 1
	RadioButton = 2
	DropdownList = 3
	EditableDropdownList = 4
properties_formated = []
for _, group in properties.iteritems():
	for prop in group:
		if prop["status"] != "normal":
			continue # skip deleted prop
		id = prop["pid"]
		parent_ids = "[ %s ]"%", ".join(map(str, prop["cids"]))
		name = prop["name"].encode("utf-8")
		if "\"" in name or name.endswith("\\"):
			print "prop name %s invalid"%prop["name"]
			continue
		is_sale_property = "true" if prop["is_sale_prop"] else "false"
		is_color_property = "true" if prop["is_color_prop"] else "false"
		control_type = InputControlType.Textbox
		if prop["is_enum_prop"]:
			if prop["multi"]:
				control_type = InputControlType.CheckBox
			elif prop["is_input_prop"]:
				control_type = InputControlType.EditableDropdownList
			else:
				control_type = InputControlType.DropdownList
		property_values = prop.get("prop_values", {}).get("prop_value", [])
		property_value_ids = ", ".join(map(lambda v: str(v["vid"]), property_values))
		property_value_ids = "[ %s ]"%property_value_ids if property_value_ids else "[]"
		properties_formated.append((
			id, parent_ids, name, is_sale_property,
			is_color_property, control_type, property_value_ids))
properties_formated.sort(key = lambda p: p[0])
with open("properties.txt", "wb") as w:
	w.write("[\r\n")
	for index, prop in enumerate(properties_formated):
		w.write("{ Id: %s, ParentCategoryIds: %s, Name: \"%s\", IsSaleProperty: %s, IsColorProperty: %s, ControlType: %s, PropertyValueIds: %s }"%prop)
		if index < len(properties_formated) - 1:
			w.write(",")
		w.write("\r\n")
	w.write("]\r\n")

# id, value
propertyValues = {}
propertyValues_formated = []
for _, group in properties.iteritems():
	for prop in group:
		if prop["status"] != "normal":
			continue # skip deleted prop
		for prop_value in prop.get("prop_values", {}).get("prop_value", []):
			vid = prop_value["vid"]
			existValue = propertyValues.get(vid)
			if existValue:
				if prop_value["name"] != existValue["name"]:
					print "prop value confict %s"%prop_value["name"]
				continue
			propertyValues[vid] = prop_value
			name = prop_value["name"].encode("utf-8")
			if "\"" in name or name.endswith("\\"):
				print "prop value name %s invalid"%prop_value["name"]
				continue
			propertyValues_formated.append((vid, name))
propertyValues_formated.sort(key = lambda v: v[0])
with open("property_values.txt", "wb") as w:
	w.write("[\r\n")
	for index, value in enumerate(propertyValues_formated):
		w.write("{ Id: %s, Name: \"%s\" }"%value)
		if index < len(propertyValues_formated) - 1:
			w.write(",")
		w.write("\r\n")
	w.write("]\r\n")
